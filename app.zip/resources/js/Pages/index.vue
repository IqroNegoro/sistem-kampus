<script setup>
defineProps({ name: String })
</script>

<template>
</template>